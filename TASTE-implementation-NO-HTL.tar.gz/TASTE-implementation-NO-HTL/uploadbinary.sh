#!/bin/bash
# first parameter = ip
scp ~/taste-workspace/b2space/TASTE-implementation/work/binaries/rpi_partition_1 pi@$1:TASEC-LAB.exe
