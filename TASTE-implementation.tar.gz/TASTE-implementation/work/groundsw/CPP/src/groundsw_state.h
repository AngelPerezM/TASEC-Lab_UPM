// Fill in this class with your context data (internal state):
// list all the variables you want global (per function instance)
#include "dataview-uniq.h"

class groundsw_state {
public:
  // Add your members here
  // int counter;

};
