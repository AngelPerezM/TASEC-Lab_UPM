// Implementation of the glue code in C handling required interfaces

// There are no required interfaces for this function...

